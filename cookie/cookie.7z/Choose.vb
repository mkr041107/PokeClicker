﻿Public Class Choose
    Private Sub pbCursor1_Click(sender As Object, e As EventArgs) Handles pbCursor1.Click
        Me.Hide()
        CookieClicker.ShowDialog()
        End
    End Sub

    Private Sub pbCursor2_Click(sender As Object, e As EventArgs) Handles pbCursor2.Click
        Me.Hide()
        form1.ShowDialog()
        End
    End Sub

    Private Sub pbCookieClickerTimed_Click(sender As Object, e As EventArgs) Handles pbCookieClickerTimed.Click
        Me.Hide()
        form1.ShowDialog()
        End
    End Sub

    Private Sub pbPokeClicker_Click(sender As Object, e As EventArgs) Handles pbPokeClicker.Click
        Me.Hide()
        CookieClicker.ShowDialog()
        End
    End Sub
End Class